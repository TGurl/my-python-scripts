#!/usr/bin/env bash
nvim -p zipr.py utils.py settings.py colors.py
