TITLE='Zipr'
VERSION='2.19'
# ---- Folders to store them
DEST_KEEP='~/USB/sexgames/keep'
DEST_USB='~/USB/sexgames'
DEST_ARC='~/Games/archives'
