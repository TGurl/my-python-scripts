#!/usr/bin/env python
import argparse
from utils import Utils

class Zipr(Utils):
    def __init__(self):
        super().__init__()

    def run(self, args):
        self.zipit(args.folder, args.destination, args.keepsaves, args.keep, args.nocheck)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument('folder', help='Folder to zip')

    parser.add_argument('-d', '--destination',
                        choices=('archives', 'usb', 'keep'),
                        default='archives',
                        required=False,
                        help='Destination for the zip file')

    parser.add_argument('-k', '--keep',
                        action='store_true',
                        default=False,
                        required=False,
                        help='Keep the source folder')

    parser.add_argument('-ks', '--keepsaves',
                        action='store_true',
                        default=False,
                        required=False,
                        help='Keep the game saves')

    parser.add_argument('-nc', '--nocheck',
                        action='store_true',
                        default=False,
                        required=False,
                        help='Do not check the created archive')

    zipr = Zipr()
    zipr.run(parser.parse_args())
