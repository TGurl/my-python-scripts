import os
import sys
import glob
import math
import zipfile

from shutil import rmtree
from colors import *
from time import sleep


class Utils:
    def __init__(self):
        self.archive_path = os.path.join('~', 'Games', 'archives')
        self.usb_path = os.path.join('~', 'USB', 'sexgames')
        self.keep_path = os.path.join(self.usb_path, 'keep')
    
    def __colorize(self, text):
        for color in Colors.colors:
            text = text.replace(color[0], color[1])
        return text

    def __decolorize(self, text):
        for code in Colors.codes:
            text = text.replace(code, '')
        return text

    def __move_up_and_clear(self, num=1):
        for _ in range(num):
            print('\033[1A', end='\x1b[2K')

    def __print(self, text, nl=False):
        newline = '\n\n' if nl else '\n'
        text = self.__colorize(text)
        print(text, end=newline)

    def __print_message(self, text, prompt='>', newline=False):
        text = f'%c{prompt}%R {text}'
        self.__print(text, nl=newline)

    def __print_warning(self, text, prompt='*', newline=False):
        text = f'%p{prompt}%R {text}'
        self.__print(text, nl=newline)
    
    def __print_success(self, text, prompt='>', newline=False):
        text = f'%g{prompt}%R {text}'
        self.__print(text, nl=newline)
    
    def __print_error(self, text, prompt='!', stop=False, newline=False):
        text = f'%r{prompt}%R {text}'
        self.__print(text, nl=newline)
        if stop:
            sys.exit(1)

    def __print_step(self, text, prompt='>', newline=False):
        text = f'%y{prompt}%R {text}'
        self.__print(text, nl=newline)
    
    def __print_substep(self, text, prompt='  └>', newline=False):
        text = f'%b{prompt}%R {text}'
        self.__print(text, nl=newline)

    def __print_header(self):
        os.system('clear')
        self.__print('%c╭──────────────────────────────────────╮%R')
        self.__print('%c│ %yZipr v3.0a %R- %gCopyleft 2023 TransGirl %c│%R')
        self.__print('%c╰──────────────────────────────────────╯%R')

    def __render_progress(self, progress, total):
        perc = (progress * 100) // total
        if isinstance(total, int):
            l = len(str(total))
        else:
            l = len(total)
        return f"{progress:{l}}/{total} [{perc:3}%]"

    def __convert_size(self, size_bytes):
        if size_bytes == 0:
            return "0B"
        size_name = ("B", "Kb", "Mb", "Gb", "Tb", "Pb", "Eb", "Zb", "Yb")
        i = int(math.floor(math.log(size_bytes, 1024)))
        p = math.pow(1024, i)
        s = round(size_bytes / p)
        return "%s %s" % (s, size_name[i])

    def __convert_to_mb(self, size_bytes):
        power = 2 ** 20
        return round(size_bytes / power)

    def do_some_checks(self, folder):
        if not os.path.exists(folder):
            self.__print_error(f"The folder %i%c{folder}%R doesn't seem to exist...", stop=True)

        if os.path.exists(self.zip_filename):
            self.__print_error(f"%i%c{self.zip_filename}%R already exists in current folder", stop=True)

        results = []
        check_paths = [self.archive_path, self.usb_path, self.keep_path]
        for cpath in check_paths:
            path = os.path.expanduser(os.path.join(cpath, self.zip_filename))
            if os.path.exists(path):
                results.append(cpath)

        if len(results) > 0:
            for path in results:
                self.__print_error(f"%i%b{self.zip_filename}%R found in %i%c{path}%R")
            sys.exit(1)

    def zipit(self, folder, destination, keepsaves, keep, nocheck):
        self.__print_header()
        self.zip_filename = folder + '.zip'
        self.zip_filename = self.zip_filename.strip()

        # -------------------------------------------------------------------------------------------
        # --- 0. Do some checks before we start
        # -------------------------------------------------------------------------------------------
        self.do_some_checks(folder)
        match destination:
            case 'usb': ttarget = os.path.join('~', 'USB', 'sexgames')
            case 'keep': ttarget = os.path.join('~', 'USB', 'sexgames', 'keep')
            case _ : ttarget = os.path.join('~', 'Games', 'archives')

        self.__print_message(f'Archiving %i%c{folder}%R to %i%c{ttarget}%R')
        del ttarget

        # -------------------------------------------------------------------------------------------
        # --- 1. clear the save files when enabled
        # -------------------------------------------------------------------------------------------
        if not keepsaves:
            self.__print_step(f'Clearing save files')
            saves_exist = False

            save_files = glob.glob(os.path.join(folder, '**', 'saves'))
            if len(save_files):
                saves_exist = True
                for path in save_files:
                    rmtree(path)
        
            self.__move_up_and_clear()
            if saves_exist:
                self.__print_success('Cleared save files')
            else:
                self.__print_success('No save files found')
        else:
            self.__print_warning('Save files not be removed')

        # -------------------------------------------------------------------------------------------
        # --- 2. Collect all the files in the folder recursively
        # -------------------------------------------------------------------------------------------
        self.__print_step(f'Collecting all files in %i%c{folder}%R')
        files = glob.glob(os.path.join(folder, '**'), recursive=True)
        self.__move_up_and_clear()
        self.__print_success('Collecting done')

        # -------------------------------------------------------------------------------------------
        # --- 3. Create the zipfile
        # -------------------------------------------------------------------------------------------
        total_files = len(files)
        progress = 1
        self.__print_step("Zipping files...", newline=True)

        archive = zipfile.ZipFile(self.zip_filename, 'w', compression=zipfile.ZIP_DEFLATED)

        for file in files:
            progress_bar = self.__render_progress(progress, total_files)
            file_str = file
            if len(file) > 30:
                # file_str = file[:22] + '..' + file[-22:]
                file_str = '..' + file[-30:]

            self.__move_up_and_clear()
            self.__print_substep(f"{progress_bar} %i{file_str}%R")
            archive.write(file)
            progress += 1
        
        archive.close()
        self.__move_up_and_clear(num=2)
        self.__print_success('Zipping done')
        
        # -------------------------------------------------------------------------------------------
        # --- 4. Check the archive
        # -------------------------------------------------------------------------------------------
        if not nocheck:
            self.__print_step(f'Checking %i%c{self.zip_filename}%R...')
            archive = zipfile.ZipFile(self.zip_filename, 'r', compression=zipfile.ZIP_DEFLATED)
            result = archive.testzip()
            archive.close()

            if result is not None:
                self.__move_up_and_clear()
                self.__print_error(f"%i%c{self.zip_filename}%R seems to be corrupt...", stop=True)
            else:
                self.__move_up_and_clear()
                self.__print_success(f"%i%c{self.zip_filename}%R is OK")
        else:
            self.__print_warning('Zipfile not checked for errors!')

        # -------------------------------------------------------------------------------------------
        # --- 5. Move the file to it's destination
        # -------------------------------------------------------------------------------------------
        self.__print_step('Moving file...')
        match destination:
            case 'usb': destination = self.usb_path
            case 'keep': destination = self.keep_path
            case _ : destination = self.archive_path

        source_size = os.stat(self.zip_filename).st_size
        # source_str = self.__convert_size(source_size)
        source_info = self.__convert_to_mb(source_size)
        lead = len(str(source_info))

        target_fn = os.path.expanduser(os.path.join(destination, self.zip_filename))

        copied = 0
        # copied_str = self.__convert_size(copied)
        copied_info = self.__convert_to_mb(copied)
        source = open(self.zip_filename, 'rb')
        target = open(target_fn, 'wb')

        perc = 0
        self.__print_substep(f"Moved {copied_info:{lead}} Mb out of {source_info} Mb [{perc:3}%]")

        while True:
            chunk = source.read(32768)
            if not chunk:
                break
            target.write(chunk)
            copied += len(chunk)
            # i = int(math.floor(math.log(copied, 1024)))
            # p = math.pow(1024, i)
            # s = round(copied / p)

            # copied_str = self.__convert_size(copied)
            copied_info = self.__convert_to_mb(copied)

            # l = len(source_str)
            perc = int(copied * 100 / source_size)
            self.__move_up_and_clear()
            self.__print_substep(f"Moved {copied_info:{lead}} Mb out of {source_info} Mb [{perc:3}%]")
            # sleep(0.001)
        
        source.close()
        target.close()

        self.__move_up_and_clear(num=2)
        self.__print_success('Moving done')
        
        # -------------------------------------------------------------------------------------------
        # --- 6. Remove zipfile when enabled
        # -------------------------------------------------------------------------------------------
        if not keep:
            self.__print_step('Removing source folder')
            rmtree(folder)
            self.__move_up_and_clear()
            self.__print_success('Source folder removed')
        else:
            self.__print_warning('Source folder kept')

        # -------------------------------------------------------------------------------------------
        # --- 7. Remove zipfile when enabled
        # -------------------------------------------------------------------------------------------
        os.remove(self.zip_filename)

        # -------------------------------------------------------------------------------------------
        # --- 8. Remove zipfile when enabled
        # -------------------------------------------------------------------------------------------
        self.__print_message('Done!')
