import os
import pygame
from random import choice
from settings import *

class Tile:
    def __init__(self, x, y, image, type='.') -> None:
        self.x, self.y = x * TILESIZE, y * TILESIZE
        self.image = image
        self.type = type

    def __repr__(self):
        return self.type

    