#!/usr/bin/env python
import pygame
from pygame.locals import *
from settings import *
from tiles import *
from board import *
from time import sleep


class Game:
    def __init__(self) -> None:
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption(TITLE)
        self.clock = pygame.time.Clock()
        self.board = Board()

    def new(self):
        self.board.create_slizes()
        self.board.populate_board()
        # self.board.show_board()

    def draw(self):
        self.screen.fill(BGCOLOR)
        for row in range(0, ROWS):
            for col in range(0, COLS):
                if self.board.board_list[col][row].type != '.':
                    # print(self.board.board_list[col][row])
                    self.screen.blit(self.board.board_list[col][row].image, (row*TILESIZE, col*TILESIZE))

        # ----------------------------------------------------------
        # ---- draw the divider lines
        # ----------------------------------------------------------
        for row in range(0, ROWS):
            pygame.draw.line(self.screen, BLACK, (row * TILESIZE, 0), (row * TILESIZE, HEIGHT), width=2)
        
        for col in range(0, COLS):
            pygame.draw.line(self.screen, BLACK, (0, col * TILESIZE), (WIDTH, col * TILESIZE), width=2)

        # ----------------------------------------------------------
        # ---- show the image
        # ----------------------------------------------------------
        pygame.display.flip()

    def events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit(0)

    def run(self):
        self.new()
        self.board.shuffle_board()
        self.running = True
        while self.running:
            
            self.draw()
            self.events()


if __name__ == "__main__":
    app = Game()
    app.run()