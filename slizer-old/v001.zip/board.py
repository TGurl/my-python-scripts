from settings import *
from tiles import *
import numpy as np
import random
import cv2

class Board:
    def __init__(self) -> None:
        self.board_list = [[Tile(col, row, TILE_EMPTY) for row in range(ROWS)] for col in range(COLS)]
        self.control_list = self.board_list

    def populate_board(self):
        for row in range(ROWS):
            for col in range(COLS):
                image = f'tile_{row}_{col}.png'
                path = os.path.join('images', 'slizes', image)
                img_surf = pygame.image.load(path).convert()
                self.board_list[row][col].image = img_surf
                self.board_list[row][col].type = 'X'

    def show_board(self):
        for row in self.board_list:
            print(row)

    def collect_images(self):
        images = []
        for img in os.listdir('images'):
            if img.endswith('.png'):
                images.append(img)
        return images
    
    def create_slizes(self):
        image = random.choice(self.collect_images())
        path = os.path.join('images', image)
        img = cv2.imread(path)
        row = 0
        for r in range(0, img.shape[0], TILESIZE):
            col = 0
            for c in range(0, img.shape[1], TILESIZE):
                filename = f"tile_{row}_{col}.png"
                path = os.path.join('images', 'slizes', filename)
                cv2.imwrite(path, img[r:r+TILESIZE, c:c+TILESIZE])
                col += 1
            row += 1

    def shuffle_board2(self):
        for _ in range(0, random.randint(100, 200)):
            for row in range(0, ROWS):
                random.shuffle(self.board_list[row])
        for _ in range(0, random.randint(100, 200)):
            random.shuffle(self.board_list)
        self.board_list[-1][-1].image = ''
        self.board_list[-1][-1].type = TILE_EMPTY

    def shuffle_board(self):
        for _ in range(0, random.randint(55, 75)):
            for row in range(0, ROWS):
                col1 = random.randint(0, COLS-1)
                col2 = col1
                while col2 == col1:
                    col2 = random.randint(0, COLS-1)
                t = self.board_list[col1][row]
                self.board_list[col1][row] = self.board_list[col2][row]
                self.board_list[col2][row] = t
                del t

            for col in range(0, COLS):
                row1 = random.randint(0, ROWS-1)
                row2 = row1
                while row2 == row1:
                    row2 = random.randint(0, ROWS-1)
                t = self.board_list[col][row1]
                self.board_list[col][row1] = self.board_list[col][row2]
                self.board_list[col][row2] = t
                del t
        
        self.board_list[-1][-1].image = ''
        self.board_list[-1][-1].type = TILE_EMPTY