import pygame
from settings import *


class Tile:
    def __init__(self, x, y, image, type):
        self.x, self.y = x * TILESIZE, y * TILESIZE
        self.image = image
        self.type = type

    def __repr__(self):
        return self.type


class Board:
    def __init__(self):
        surf = pygame.Surface((TILESIZE, TILESIZE))
        self.board_list = [[Tile(col, row, surf, "X") for row in range(ROWS)] for col in range(COLS)]
        self.correct = []

    def slice_image(self, x, y, surface):
        surf = pygame.Surface((TILESIZE, TILESIZE))
        tile = pygame.Rect((x, y), (x + TILESIZE, y + TILESIZE))
        chop = pygame.transform.chop(surface, tile)
        chop.blit(surf, (0, 0))
        return chop

    def populate_board(self, surface):
        for row in self.board_list:
            for col in row:
                x = col.x
                y = col.y
                tile = self.slice_image(y, x, surface)
                self.board_list[y // TILESIZE][x // TILESIZE].image = tile
        self.board_list[-1][-1].image = EMPTY_TILE
        self.board_list[-1][-1].type = '.'

    def display_board(self):
       for row in self.board_list:
           print(row)
