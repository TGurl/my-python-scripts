import os
import pygame

TITLE = 'Slizer'
WIDTH = 960
COLS = 8
HEIGHT = WIDTH
ROWS = COLS
TILESIZE = WIDTH // COLS
TOPLEFT = (0, 0)

# colors (r, g, b)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
DARKGREY = (40, 40, 40)
LIGHTGREY = (100, 100, 100)
GREEN = (0, 255, 0)
DARKGREEN = (0, 200, 0)
BLUE = (0, 0, 255)
RED = (255, 0, 0)
PINK = (255, 0, 255)
YELLOW = (255, 255, 0)
BGCOLOR = DARKGREY

EMPTY_TILE = pygame.transform.scale(pygame.image.load(os.path.join('images', 'empty.png')), (TILESIZE, TILESIZE))
