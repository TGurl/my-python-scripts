#!/usr/bin/env python
import os
import pygame
import random
from settings import *
from sprites import *

class Slizer:
    def __init__(self):
        self.board = Board()
        self.clock = pygame.time.Clock()

    def collect_all_images(self):
        imglist = []
        valid = ['.jpg', '.png', '.webp']
        for img in os.listdir('images'):
            _, extension = os.path.splitext(img)
            if extension in valid and img != 'empty.png':
                imglist.append(os.path.join('images', img))
        return imglist

    def create_screen(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption(TITLE)
        self.screen.fill(BGCOLOR)

    def load_image(self):
        imglist = self.collect_all_images()
        photo = random.choice(imglist)
        print('--->', photo)
        self.full_surface = pygame.image.load(photo).convert()
        self.board.populate_board(self.full_surface)

    def new_game(self):
        self.clock.tick(60)
        # self.board.display_board()
        self.create_screen()
        self.load_image()
        self.mx, self.my = 0, 0
        self.screen.blit(self.full_surface, (0,0))
        pygame.time.delay(1000)

    def draw_lines(self):
        for row in range(ROWS):
            for col in range(COLS):
                x = row * TILESIZE
                y = col * TILESIZE
                pygame.draw.line(self.screen, BLACK, (x - 1, 0), (x - 1, HEIGHT), width=3)
                pygame.draw.line(self.screen, BLACK, (0, y - 1), (WIDTH, y - 1), width=3)

    def events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit(0)

            if event.type == pygame.MOUSEBUTTONDOWN:
                self.mx, self.my = event.pos


    def run(self):
        while True:
            self.events()

            # show the full photo and wait for mouseclick
            self.screen.blit(self.full_surface, TOPLEFT)

            # draw dividing lines
            self.draw_lines()


            for row in range(ROWS):
                for col in range(COLS):
                    tile = self.board.board_list[col][row].image
                    x, y = self.board.board_list[col][row].x, self.board.board_list[col][row].y
                    self.screen.blit(tile, (x, y))


            # render the screen
            pygame.display.flip()


if __name__ == '__main__':
    app = Slizer()
    app.new_game()
    app.run()
