#!/usr/bin/env python
from utils import Utils
from settings import *
import argparse


class Wallpaper(Utils):
    def __init__(self, args):
        super().__init__()
        self.action = args.action

    def run(self):
        if self.check_if_config_exists() and self.action not in ['c', 'clear']:
            self.load_config()
        
        match self.action:
            case 'n' | 'next': self.goto_next_wallpaper()
            case 'p' | 'previous': self.goto_previous_wallpaper()
            case 'r' | 'restart': self.restart_timer()
            case 's' | 'setup': self.setup_menu()
            case 'c' | 'clear': self.clear_config()

        if not self.check_if_config_exists():
            self.save_config()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog='wp',
                                     formatter_class=argparse.RawTextHelpFormatter)

    if not DEBUG:
        available = ('n', 'p', 'r', 's', 'next', 'previous', 'restart', 'setup')
        showhelp = ActionHelp
    else:
        available = ('n', 'p', 'r', 's', 'c', 'next', 'previous', 'restart', 'setup', 'clear')
        showhelp = ActionHelpDebug
            
    parser.add_argument('action', nargs='?', choices=available,
                        default = 'setup', type=lambda s : s.lower(), help=showhelp)

    app = Wallpaper(parser.parse_args())
    app.run()
