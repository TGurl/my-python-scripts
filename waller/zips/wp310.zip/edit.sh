#!/usr/bin/env bash
nvim -p wp.py utils.py settings.py
