import os

DEBUG = True

Config = {
        'title':   'Waller',
        'version': '0.0.1',
        'configdir': os.path.expanduser(os.path.join('~', '.local', 'share', 'wallpaper')),
        'configfile': 'wallpaper.pickle',
        'walldir': os.path.join('/', 'data', 'pictures', 'walls'),
        'maincat': None,
        'subcat': None,
        'current': None,
        'sddmgrub': False,
        'random': False
        }

ActionHelp = """
n, next     = go to next wallpaper
p, previous = go to previous wallpaper
r, restart  = restart the timer daemon
s, setup    = enter the setup menu
"""

ActionHelpDebug = """
n, next     = go to next wallpaper
p, previous = go to previous wallpaper
r, restart  = restart the timer daemon
s, setup    = enter the setup menu
c, clear    = clear the config
"""
