import os, sys, pickle, shutil, glob
from time import sleep
from settings import *
from rich import print

class Utils:
    def __init__(self):
        pass

    def check_if_config_exists(self):
        if not os.path.exists(Config['configdir']):
            os.mkdir(Config['configdir'])

        path = os.path.join(Config['configdir'], Config['configfile'])
        return True if os.path.exists(path) else False

    def clear_config(self):
        shutil.rmtree(Config['configdir'])

    def save_config(self):
        path = os.path.join(Config['configdir'], Config['configfile'])
        pickle_out = open(path, 'wb')
        pickle.dump(Config, pickle_out)
        pickle_out.close()

    def load_config(self):
        path = os.path.join(Config['configdir'], Config['configfile'])
        pickle_in = open(path, 'rb')
        data = pickle.load(pickle_in)
        pickle_in.close()

        Config['configdir'] = data['configdir']
        Config['configfile'] = data['configfile']
        Config['walldir'] = data['walldir']
        Config['maincat'] = data['maincat']
        Config['subcat'] = data['subcat']
        Config['current'] = data['current']
        Config['sddmgrub'] = data['sddmgrub']
        Config['random'] = data['random']

    def create_wallpaper_collection(self):
        wallpapers = []
        pattern = os.path.join(Config['walldir'], Config['maincat'], Config['subcat'], '*.png')
        wallpapers = glob.glob(pattern)
        wallpapers.sort()
        return wallpapers

    def check_maincat_subcat(self):
        if Config['maincat'] is None or Config['subcat'] is None:
            return False
        else:
            return True

    def goto_next_wallpaper(self):
        if Config['random']:
            self.goto_random_wallpaper()

        if not self.check_maincat_subcat():
            self.setup_menu()

    def goto_previous_wallpaper(self):
        if Config['random']:
            self.goto_random_wallpaper()
        
        if not self.check_maincat_subcat():
            self.setup_menu()

    def goto_random_wallpaper(self):
        if not self.check_maincat_subcat():
            self.setup_menu()

    def restart_timer(self):
        pass

    def setup_menu(self):
        content = f"[green]>> {Config['title']} {Config['version']} <<[/]"
        content += '\n\n'
        content += "[cyan][[yellow]1[/][cyan]][/][/] Choose main category\n"
        content += "[cyan][[yellow]2[/][cyan]][/][/] Choose sub category\n"
        content += "[cyan][[yellow]3[/][cyan]][/][/] Set randomize to True\n"
        content += "[cyan][[yellow]4[/][cyan]][/][/] Set change grub/sddm to True\n"
        content += '\n'
        content += f"[cyan][[red]q[/][cyan]][/][/] Quit {Config['title']}\n"

        while True:
            os.system('clear')
            print(content)
            response = input("> ").lower()
            if response not in ['1', '2', '3', '4', 'q']:
                print('[red]!![/] That is not a valid option')
                sleep(1.2)
            elif response in ['q', 'quit']:
                break

